// Brenda Spears (2201841702)
// Sreeya Reddy (2201816165)
// Astrology (Horoscope)

#include <iostream>
#include "menu.h"

int main() {
    Menu m;
    m.list();
}