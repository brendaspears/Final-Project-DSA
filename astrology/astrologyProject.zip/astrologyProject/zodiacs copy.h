//
// Created by Brenda Spears on 2019-06-30.
//

#ifndef ASTROLOGY_ZODIACS_H
#define ASTROLOGY_ZODIACS_H

#include <iostream>
#include <string>
#include <algorithm>
#include <cctype>
#include <fstream>
#include <vector>

using namespace std;

class Zodiacs{
private:

public:
    Zodiacs()
    {
        element.empty();
    }
    vector <string> element;

};


#endif //ASTROLOGY_ZODIACS_H
